import { parse, type, prompt, input } from "./io.js";
import pause from "./pause.js";

/** Boot screen */

const WINDOW_SELECTOR = ".window";
const DEFAULT_TERMINAL_SELECTOR = ".terminal";

const windowState = new WeakMap();

let activeWindow = null;
let activeTypingHost = null;
let zCounter = 100;
let openCount = 0;

function getTerminal() {
    return document.querySelector(DEFAULT_TERMINAL_SELECTOR);
}

function getLiveInput() {
    return document.querySelector('[contenteditable="true"]');
}

function focusTerminalInput() {
    const liveInput = getLiveInput();
    liveInput?.focus();
    activeTypingHost = null;
}

function getWindowState(root) {
    if (!windowState.has(root)) {
        windowState.set(root, {
            openedOnce: false,
            prevHeight: "",
            acceptsTerminal: false,
            terminalTarget: null
        });
    }
    return windowState.get(root);
}

function isWindowVisible(root) {
    return !!root && !root.classList.contains("hidden");
}

function isWindowMinimized(root) {
    return !!root && root.classList.contains("minimized");
}

function ensureWindowSurface(root) {
    if (!root) return;
    if (root.querySelector(":scope > .window-surface")) return;

    const surface = document.createElement("div");
    surface.className = "window-surface";

    while (root.firstChild) {
        surface.appendChild(root.firstChild);
    }

    root.appendChild(surface);
}

function syncWindowTypingMetadata(root) {
    const state = getWindowState(root);

    state.acceptsTerminal =
        root.hasAttribute("data-accepts-terminal") ||
        !!root.querySelector("[data-terminal-target]");

    state.terminalTarget =
        root.querySelector("[data-terminal-target]") ||
        root.querySelector(".window-terminal") ||
        null;
}

function focusTypingHost(root) {
    if (!root) {
        focusTerminalInput();
        return;
    }

    syncWindowTypingMetadata(root);
    const state = getWindowState(root);

    if (!state.acceptsTerminal) {
        focusTerminalInput();
        return;
    }

    activeTypingHost =
        state.terminalTarget ||
        root.querySelector(".content") ||
        root.querySelector(".body") ||
        getTerminal();

    getLiveInput()?.focus();
}

export function getTypingHost() {
    return activeTypingHost || getTerminal();
}

export async function typeInActiveHost(text, options = {}) {
    return type(text, options, getTypingHost());
}

function getCascadeAnchor(root) {
    if (
        activeWindow &&
        activeWindow !== root &&
        isWindowVisible(activeWindow) &&
        !isWindowMinimized(activeWindow)
    ) {
        return activeWindow;
    }

    const visibleWindows = [...document.querySelectorAll(WINDOW_SELECTOR)]
        .filter(win =>
            win !== root &&
            isWindowVisible(win) &&
            !isWindowMinimized(win)
        )
        .sort((a, b) => (Number(a.style.zIndex) || 0) - (Number(b.style.zIndex) || 0));

    return visibleWindows.at(-1) || null;
}

function clampWindowToCRT(left, top, root) {
    const crt = document.getElementById("crt");
    const crtRect = crt?.getBoundingClientRect();
    const rootRect = root.getBoundingClientRect();

    if (!crtRect) {
        return { left, top };
    }

    const margin = 16;
    const width = rootRect.width || root.offsetWidth || 640;
    const height = rootRect.height || root.offsetHeight || 480;

    const minLeft = crtRect.left + margin;
    const minTop = crtRect.top + margin;
    const maxLeft = Math.max(minLeft, crtRect.right - width - margin);
    const maxTop = Math.max(minTop, crtRect.bottom - height - margin);

    return {
        left: Math.max(minLeft, Math.min(left, maxLeft)),
        top: Math.max(minTop, Math.min(top, maxTop))
    };
}

function applyInitialWindowPosition(root) {
    const state = getWindowState(root);
    if (state.openedOnce) return;

    root.style.position = "fixed";

    const offsetX = 32;
    const offsetY = 24;

    let left = 48 + openCount * 12;
    let top = 40 + openCount * 10;

    const anchor =
        activeWindow &&
        activeWindow !== root &&
        isWindowVisible(activeWindow) &&
        !isWindowMinimized(activeWindow)
            ? activeWindow
            : [...document.querySelectorAll(WINDOW_SELECTOR)]
                .filter(win =>
                    win !== root &&
                    isWindowVisible(win) &&
                    !isWindowMinimized(win)
                )
                .sort((a, b) => (Number(a.style.zIndex) || 0) - (Number(b.style.zIndex) || 0))
                .at(-1);

    if (anchor) {
        const anchorLeft = parseFloat(anchor.style.left);
        const anchorTop = parseFloat(anchor.style.top);

        left = (Number.isFinite(anchorLeft) ? anchorLeft : anchor.getBoundingClientRect().left) + offsetX;
        top = (Number.isFinite(anchorTop) ? anchorTop : anchor.getBoundingClientRect().top) + offsetY;
    }

    const crt = document.getElementById("crt");
    const crtRect = crt?.getBoundingClientRect();
    const rect = root.getBoundingClientRect();
    const width = rect.width || root.offsetWidth || 640;
    const height = rect.height || root.offsetHeight || 480;
    const margin = 16;

    if (crtRect) {
        const minLeft = crtRect.left + margin;
        const minTop = crtRect.top + margin;
        const maxLeft = Math.max(minLeft, crtRect.right - width - margin);
        const maxTop = Math.max(minTop, crtRect.bottom - height - margin);

        left = Math.max(minLeft, Math.min(left, maxLeft));
        top = Math.max(minTop, Math.min(top, maxTop));
    }

    const visibleWindows = [...document.querySelectorAll(WINDOW_SELECTOR)]
        .filter(win =>
            win !== root &&
            isWindowVisible(win) &&
            !isWindowMinimized(win)
        );

    let tries = 0;
    while (
        visibleWindows.some(win => {
            const winLeft = parseFloat(win.style.left);
            const winTop = parseFloat(win.style.top);
            return Math.abs(winLeft - left) < 20 && Math.abs(winTop - top) < 20;
        }) &&
        tries < 20
    ) {
        left += offsetX;
        top += offsetY;

        if (crtRect) {
            const minLeft = crtRect.left + margin;
            const minTop = crtRect.top + margin;
            const maxLeft = Math.max(minLeft, crtRect.right - width - margin);
            const maxTop = Math.max(minTop, crtRect.bottom - height - margin);

            if (left > maxLeft) left = minLeft;
            if (top > maxTop) top = minTop;
        }

        tries += 1;
    }

    root.style.left = `${Math.round(left)}px`;
    root.style.top = `${Math.round(top)}px`;

    state.openedOnce = true;
    openCount += 1;
}

function syncWindowBackground(root) {
    if (!root) return;

    const surface = root.querySelector(":scope > .window-surface");
    const crt = document.getElementById("crt");
    if (!surface || !crt) return;

    const winRect = root.getBoundingClientRect();
    const crtRect = crt.getBoundingClientRect();

    const offsetX = crtRect.left - winRect.left;
    const offsetY = crtRect.top - winRect.top;

    surface.style.setProperty("--crt-offset-x", `${offsetX}px`);
    surface.style.setProperty("--crt-offset-y", `${offsetY}px`);
}

function setActiveWindow(root, { focusTyping = false } = {}) {
    if (!root || !isWindowVisible(root) || isWindowMinimized(root)) return;

    activeWindow = root;
    zCounter = Math.min(zCounter + 1, 8000); // stay below scanlines at 8888/9999

    document.querySelectorAll(WINDOW_SELECTOR).forEach((win) => {
        win.classList.toggle("active-window", win === root);
    });

    root.style.position = "fixed";
    root.style.zIndex = String(zCounter);

    const crt = document.getElementById("crt");
    if (root.parentElement === crt) {
        crt.appendChild(root);
    }

    syncWindowBackground(root);

    if (focusTyping) {
        focusTypingHost(root);
    }
}

function clearActiveWindow(root = activeWindow) {
    if (root && activeWindow === root) {
        activeWindow = null;
    }

    document.querySelectorAll(WINDOW_SELECTOR).forEach((win) => {
        win.classList.remove("active-window");
    });
}

function restoreTerminalFocus() {
    activeTypingHost = null;
    focusTerminalInput();
}

function focusWindowIfNeeded(root) {
    if (!root || !isWindowVisible(root) || isWindowMinimized(root)) {
        restoreTerminalFocus();
        return;
    }

    syncWindowTypingMetadata(root);
    const state = getWindowState(root);

    if (state.acceptsTerminal) {
        focusTypingHost(root);
    } else {
        restoreTerminalFocus();
    }
}

async function on() {
    await power();
    boot();
}

async function power() {
    await pause(0.5);
    document.getElementById("monitor").classList.toggle("turn-on");
    document.getElementById("monitor").classList.toggle("on");
    return;
}

export async function boot() {
    clear();

    const Debug =
        location.hostname === "localhost" ||
        location.hostname === "127.0.0.1" ||
        location.hostname === "::1";

    if (!Debug) {
        await type(`Cyber Industries(TM) CV-2077 terminal interface`, {
            initialWait: 2000
        });
        await type(`Loading.....`, {
            initialWait: 500
        });
    }

    if (!Debug) {
        await type(`


⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⠙⠻⢶⣄⡀⠀⠀⠀⢀⣤⠶⠛⠛⡇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣇⠀⠀⣙⣿⣦⣤⣴⣿⣁⠀⠀⣸⠇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣡⣾⣿⣿⣿⣿⣿⣿⣿⣷⣌⠋⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿⣷⣄⡈⢻⣿⡟⢁⣠⣾⣿⣦⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⣿⠘⣿⠃⣿⣿⣿⣿⡏⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠀⠈⠛⣰⠿⣆⠛⠁⠀⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⣿⣦⠀⠘⠛⠋⠀⣴⣿⠁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣶⣾⣿⣿⣿⣿⡇⠀⠀⠀⢸⣿⣏⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣠⣶⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠀⠀⠀⠾⢿⣿⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⡿⠟⠋⣁⣠⣤⣤⡶⠶⠶⣤⣄⠈⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢰⣿⣿⣮⣉⣉⣉⣤⣴⣶⣿⣿⣋⡥⠄⠀⠀⠀⠀⠉⢻⣄⠀⠀⠀⠀⠀
⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⣋⣁⣤⣀⣀⣤⣤⣤⣤⣄⣿⡄⠀⠀⠀⠀
⠀⠀⠀⠀⠙⠿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠛⠋⠉⠁⠀⠀⠀⠀⠈⠛⠃⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀`, {
            initialWait: 0,
            wait: 5,
            fox: true,
        });
        await type(`Welcome to FoxOS ver. 1.33.7`, {
            initialWait: 100,
        });
        await type(`"Harmony engineered."`, {
            initialWait: 100,
        });
    }

    await type(`Try 'HELP' for commands.`, {
        initialWait: 100,
    });

    await pause();
    return main();
}

/** Main input terminal, recursively calls itself */
export async function main() {
    let command = await input();
    try {
        await parse(command);
    } catch (e) {
        if (e.message) await type(e.message);
    }
    main();
}

export function addClasses(el, ...cls) {
    let list = [...cls].filter(Boolean);
    el.classList.add(...list);
}

export function getScreen(...cls) {
    let div = document.createElement("div");
    addClasses(div, "fullscreen", ...cls);
    document.querySelector("#crt").appendChild(div);
    return div;
}

export function toggleFullscreen(isFullscreen) {
    document.body.classList.toggle("fullscreen", isFullscreen);
}

/** Attempts to load template HTML from the given path and includes them in the <head>. */
export async function loadTemplates(path) {
    let txt = await fetch(path).then((res) => res.text());
    let html = new DOMParser().parseFromString(txt, "text/html");
    let templates = html.querySelectorAll("template");

    templates.forEach((template) => {
        document.head.appendChild(template);
    });
}

/** Clones the template and adds it to the container. */
export async function addTemplate(id, container, options = {}) {
    let template = document.querySelector(`template#${id}`);
    if (!template) {
        throw Error("Template not found");
    }

    let clone = document.importNode(template.content, true);

    if (template.dataset.type) {
        await type(clone.textContent, options, container);
    } else {
        container.appendChild(clone);
    }

    return container.childNodes;
}

/** Creates a new screen and loads the given template into it. */
export async function showTemplateScreen(id) {
    let screen = getScreen(id);
    await addTemplate(id, screen);
    return screen;
}

export function el(
    type,
    container = document.querySelector(".terminal"),
    cls = "",
    attrs
) {
    let el = document.createElement(type);
    addClasses(el, cls);

    container.appendChild(el);

    if (attrs) {
        Object.entries(attrs).forEach(([key, value]) => {
            el.setAttribute(key, value);
        });
    }
    return el;
}

export function div(...args) {
    return el("div", ...args);
}

export function clear(screen = document.querySelector(".terminal")) {
    screen.innerHTML = "";
}

export function openWindow(idOrRoot, options = {}) {
    const root = typeof idOrRoot === "string"
        ? document.getElementById(idOrRoot)
        : idOrRoot;

    if (!root) return null;

    ensureWindowSurface(root);
    syncWindowTypingMetadata(root);

    const wasHidden = root.classList.contains("hidden");
    const wasMinimized = root.classList.contains("minimized");

    root.classList.remove("hidden");
    root.style.display = "";

    if (wasMinimized) {
        const state = getWindowState(root);
        root.classList.remove("minimized");
        root.style.height = state.prevHeight || "";
    }

    if (wasHidden) {
        applyInitialWindowPosition(root);
    }

    root.querySelectorAll("[data-scrollbox]").forEach(setupFakeScrollbar);

    // Fix transparency snap: sync after browser paints the real position
    syncWindowBackground(root);
    requestAnimationFrame(() => {
        syncWindowBackground(root);
        requestAnimationFrame(() => syncWindowBackground(root));
    });

    setActiveWindow(root, {
        focusTyping: options.focusTyping ?? true
    });

    return root;
}

export function closeWindow(idOrRoot) {
    const root = typeof idOrRoot === "string"
        ? document.getElementById(idOrRoot)
        : idOrRoot;

    if (!root) return;

    root.classList.add("hidden");
    root.classList.remove("active-window");

    if (activeWindow === root) {
        clearActiveWindow(root);
        restoreTerminalFocus();
    }
}

export function minimizeWindow(idOrRoot) {
    const root = typeof idOrRoot === "string"
        ? document.getElementById(idOrRoot)
        : idOrRoot;

    if (!root) return;

    const state = getWindowState(root);

    if (!root.classList.contains("minimized")) {
        state.prevHeight = root.style.height;
        root.classList.add("minimized");
        root.style.height = "auto";

        if (activeWindow === root) {
            clearActiveWindow(root);
            restoreTerminalFocus();
        }
    } else {
        root.classList.remove("minimized");
        root.style.height = state.prevHeight || "";
        syncWindowBackground(root);
        setActiveWindow(root, {
            focusTyping: state.acceptsTerminal
        });
    }
}

export function setupWindow(root) {
    if (!root) return;

    ensureWindowSurface(root);
    syncWindowTypingMetadata(root);
    syncWindowBackground(root);

    if (!root.style.zIndex) {
        root.style.zIndex = "1";
    }

    const titlebar = root.querySelector(".titlebar");
    const minimizeBtn = root.querySelector(".minimize");
    const closeBtn = root.querySelector(".close");
    const resizeHandle = root.querySelector("[data-resize]");

    let dragging = false;
    let resizing = false;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;
    let startWidth = 0;
    let startHeight = 0;

    const onWindowMouseDown = () => {
        if (!isWindowVisible(root) || isWindowMinimized(root)) return;
        setActiveWindow(root, { focusTyping: false });
    };

    const onMouseDown = (e) => {
        if (e.target.closest("button")) return;
        if (e.target.closest(".buttons")) return;

        setActiveWindow(root, { focusTyping: false });

        dragging = true;

        const rect = root.getBoundingClientRect();
        startX = e.clientX;
        startY = e.clientY;
        startLeft = rect.left;
        startTop = rect.top;

        document.body.style.userSelect = "none";
    };

    const onResizeMouseDown = (e) => {
        setActiveWindow(root, { focusTyping: false });

        resizing = true;

        const rect = root.getBoundingClientRect();
        startX = e.clientX;
        startY = e.clientY;
        startWidth = rect.width;
        startHeight = rect.height;

        document.body.style.userSelect = "none";
        e.preventDefault();
        e.stopPropagation();
    };

    const onMouseMove = (e) => {
        if (dragging) {
            root.style.left = `${startLeft + (e.clientX - startX)}px`;
            root.style.top = `${startTop + (e.clientY - startY)}px`;
            syncWindowBackground(root);
        }

        if (resizing) {
            root.style.width = `${Math.max(320, startWidth + (e.clientX - startX))}px`;
            root.style.height = `${Math.max(220, startHeight + (e.clientY - startY))}px`;
            syncWindowBackground(root);
            root.querySelectorAll("[data-scrollbox]").forEach(setupFakeScrollbar);
        }
    };

    const onMouseUp = () => {
        if (!dragging && !resizing) return;

        dragging = false;
        resizing = false;
        document.body.style.userSelect = "";

        syncWindowBackground(root);
        focusWindowIfNeeded(root);
    };

    const onMinimize = (e) => {
        e.preventDefault();
        e.stopPropagation();
        minimizeWindow(root);
    };

    const onClose = (e) => {
        e.preventDefault();
        e.stopPropagation();
        closeWindow(root);
    };

    const onClick = (e) => {
        if (!isWindowVisible(root) || isWindowMinimized(root)) return;

        setActiveWindow(root, { focusTyping: false });

        const inTypingRegion =
            e.target.closest("[data-terminal-target]") ||
            e.target.closest(".window-terminal");

        if (inTypingRegion) {
            focusTypingHost(root);
            return;
        }

        const state = getWindowState(root);
        if (state.acceptsTerminal && !e.target.closest(".titlebar")) {
            focusTypingHost(root);
        }
    };

    const onResize = () => syncWindowBackground(root);

    titlebar?.addEventListener("mousedown", onMouseDown);
    resizeHandle?.addEventListener("mousedown", onResizeMouseDown);
    root.addEventListener("mousedown", onWindowMouseDown);
    root.addEventListener("click", onClick);
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
    minimizeBtn?.addEventListener("click", onMinimize);
    closeBtn?.addEventListener("click", onClose);
    window.addEventListener("resize", onResize);

    return () => {
        titlebar?.removeEventListener("mousedown", onMouseDown);
        resizeHandle?.removeEventListener("mousedown", onResizeMouseDown);
        root.removeEventListener("mousedown", onWindowMouseDown);
        root.removeEventListener("click", onClick);
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
        minimizeBtn?.removeEventListener("click", onMinimize);
        closeBtn?.removeEventListener("click", onClose);
        window.removeEventListener("resize", onResize);
    };
}

function setupAllWindows() {
    document.querySelectorAll(WINDOW_SELECTOR).forEach((win) => {
        setupWindow(win);
        syncWindowBackground(win);
    });
}

function handleEscapeKey(event) {
    if (event.key !== "Escape") return;

    const liveInput = getLiveInput();

    if (!activeWindow) return;
    if (!isWindowVisible(activeWindow) || isWindowMinimized(activeWindow)) return;

    const state = getWindowState(activeWindow);
    const terminalHasFocus = document.activeElement === liveInput && !state.acceptsTerminal;

    if (terminalHasFocus) return;

    closeWindow(activeWindow);
}

function setupGlobalFocusBehavior() {
    const crt = document.getElementById("crt");

    crt?.addEventListener("click", (e) => {
        const clickedWindow = e.target.closest(WINDOW_SELECTOR);

        if (!clickedWindow) {
            clearActiveWindow();
            restoreTerminalFocus();
            return;
        }

        if (clickedWindow.classList.contains("hidden") || clickedWindow.classList.contains("minimized")) {
            restoreTerminalFocus();
            return;
        }

        syncWindowTypingMetadata(clickedWindow);
        const state = getWindowState(clickedWindow);

        if (!state.acceptsTerminal) {
            restoreTerminalFocus();
        }
    });

    document.addEventListener("keydown", handleEscapeKey);
}

/**
 * Scrollbar
 */
function setupFakeScrollbar(root) {
    const viewport = root.querySelector("[data-viewport]");
    const track = root.querySelector("[data-track]");
    const thumb = root.querySelector("[data-thumb]");
    const buttons = root.querySelectorAll("[data-dir]");

    if (!viewport || !track || !thumb) return;

    if (root._fakeScrollbarCleanup) {
        root._fakeScrollbarCleanup();
    }

    let dragging = false;
    let startY = 0;
    let startTop = 0;
    let holdTimer = null;
    let holdInterval = null;

    const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

    function metrics() {
        const trackH = track.clientHeight;
        const viewH = viewport.clientHeight;
        const scrollH = viewport.scrollHeight;
        const maxScroll = Math.max(0, scrollH - viewH);
        const thumbH = maxScroll
            ? Math.max(24, (viewH / scrollH) * trackH)
            : trackH;
        const maxThumbTop = Math.max(0, trackH - thumbH);

        return { trackH, viewH, scrollH, maxScroll, thumbH, maxThumbTop };
    }

    function paint() {
        const { trackH, viewH, scrollH, maxScroll, thumbH, maxThumbTop } = metrics();

        if (!trackH || !viewH) {
            thumb.style.display = "none";
            return;
        }

        thumb.style.height = `${thumbH}px`;

        if (scrollH <= viewH || !maxScroll) {
            thumb.style.top = "0px";
            thumb.style.display = "none";
            return;
        }

        thumb.style.display = "block";
        thumb.style.visibility = "visible";
        thumb.style.opacity = "1";

        const top = (viewport.scrollTop / maxScroll) * maxThumbTop;
        thumb.style.top = `${top}px`;
    }

    function paintSoon() {
        requestAnimationFrame(() => {
            paint();
            requestAnimationFrame(paint);
        });
    }

    function scrollByStep(dir) {
        const step = Number(getComputedStyle(root).getPropertyValue("--sb-step")) || 32;
        viewport.scrollTop += step * dir;
        paintSoon();
    }

    function startHold(dir) {
        scrollByStep(dir);
        holdTimer = setTimeout(() => {
            holdInterval = setInterval(() => scrollByStep(dir), 40);
        }, 300);
    }

    function stopHold() {
        clearTimeout(holdTimer);
        clearInterval(holdInterval);
        holdTimer = null;
        holdInterval = null;
    }

    const onThumbMouseDown = (e) => {
        e.preventDefault();
        const thumbRect = thumb.getBoundingClientRect();
        dragging = true;
        startY = e.clientY;
        startTop = thumbRect.top - track.getBoundingClientRect().top;
        thumb.classList.add("dragging");
    };

    const onMouseMove = (e) => {
        if (!dragging) return;

        const { maxScroll, maxThumbTop } = metrics();
        const nextTop = clamp(startTop + (e.clientY - startY), 0, maxThumbTop);
        thumb.style.top = `${nextTop}px`;

        viewport.scrollTop = maxThumbTop
            ? (nextTop / maxThumbTop) * maxScroll
            : 0;
    };

    const onMouseUp = () => {
        dragging = false;
        thumb.classList.remove("dragging");
        stopHold();
    };

    const onTrackMouseDown = (e) => {
        if (e.target === thumb) return;

        const rect = track.getBoundingClientRect();
        const clickY = e.clientY - rect.top;
        const thumbTop = thumb.offsetTop;
        const thumbMid = thumbTop + thumb.offsetHeight / 2;

        viewport.scrollTop += clickY < thumbMid
            ? -viewport.clientHeight * 0.9
            : viewport.clientHeight * 0.9;

        paintSoon();
    };

    const onViewportScroll = () => paint();
    const onWindowResize = () => paintSoon();

    thumb.addEventListener("mousedown", onThumbMouseDown);
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
    track.addEventListener("mousedown", onTrackMouseDown);
    viewport.addEventListener("scroll", onViewportScroll);
    window.addEventListener("resize", onWindowResize);

    buttons.forEach((btn) => {
        const dir = Number(btn.dataset.dir);

        const onMouseDown = () => startHold(dir);
        const onMouseLeave = () => stopHold();
        const onMouseUpBtn = () => stopHold();
        const onClick = (e) => e.preventDefault();

        btn.addEventListener("mousedown", onMouseDown);
        btn.addEventListener("mouseleave", onMouseLeave);
        btn.addEventListener("mouseup", onMouseUpBtn);
        btn.addEventListener("click", onClick);

        btn._fakeScrollbarHandlers = { onMouseDown, onMouseLeave, onMouseUpBtn, onClick };
    });

    const resizeObserver = new ResizeObserver(() => paintSoon());
    resizeObserver.observe(root);
    resizeObserver.observe(track);
    resizeObserver.observe(viewport);

    const mutationObserver = new MutationObserver(() => paintSoon());
    mutationObserver.observe(viewport, {
        childList: true,
        subtree: true,
        characterData: true
    });

    root._fakeScrollbarCleanup = () => {
        thumb.removeEventListener("mousedown", onThumbMouseDown);
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
        track.removeEventListener("mousedown", onTrackMouseDown);
        viewport.removeEventListener("scroll", onViewportScroll);
        window.removeEventListener("resize", onWindowResize);
        resizeObserver.disconnect();
        mutationObserver.disconnect();

        buttons.forEach((btn) => {
            const h = btn._fakeScrollbarHandlers;
            if (!h) return;
            btn.removeEventListener("mousedown", h.onMouseDown);
            btn.removeEventListener("mouseleave", h.onMouseLeave);
            btn.removeEventListener("mouseup", h.onMouseUpBtn);
            btn.removeEventListener("click", h.onClick);
            delete btn._fakeScrollbarHandlers;
        });
    };

    paintSoon();
    setTimeout(paintSoon, 0);
    setTimeout(paintSoon, 30);
    setTimeout(paintSoon, 120);
}

function initWindows() {
    setupAllWindows();

    ["blog", "recipes", "about", "links"].forEach((id) => {
        const win = document.getElementById(id);
        if (win) {
            syncWindowBackground(win);
            win.querySelectorAll("[data-scrollbox]").forEach(setupFakeScrollbar);
        }
    });

    setupGlobalFocusBehavior();
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
        initWindows();
        on();
    });
} else {
    initWindows();
    on();
}